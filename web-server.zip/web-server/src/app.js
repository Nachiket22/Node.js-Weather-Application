const path = require('path');//path module is inbuilt module to play with path hahaha

const geocode = require('./utils/geocode');
const geolocation = require('./utils/forecast');

const express = require ('express');
const hbs = require('hbs');
const app = express();


//console.log(__dirname)
//console.log(path.join(__dirname, '../public'))//'..' is to go back one folder and '../..' is to go back two folders

//Define paths for express config
const publicpath = path.join(__dirname, '/');
const viewpath = path.join(__dirname, '/templates/views');
const partials = path.join(__dirname, '/templates/partials');



//Setup handlebar engine and  views location
app.set('view engine', 'hbs') //hbs is a express. js wrapper for the handlebars. js javascript template engine. Handlebars. js is a template engine to make writing html code easier
//To setup hbs view engine, you need to write this middleware in your index.js as above two lines
app.set('views',viewpath );//path join is very im
hbs.registerPartials(partials);

//steup static directory to serve 
app.use(express.static(publicpath))

//we have used renderer instead of send to render the hbs view it takes name of hbs and the object that 
//we are going to use in index.hbs with {{}} two flower brackets in any tag
app.get('', (req, res)=>{
    res.render('index',{
        title : 'Weather',
        name : 'Nachiket Singh'
    })
})

app.get('/about', (req,res)=>{
    res.render('about',{
        title : 'About Me',
        name : 'Nachiket Singh'
    })
})

app.get('/help', (req,res) =>{
    res.render('help',{
        title : 'Help Page',
        name : 'Nachiket Singh',
        help : 'I am  here to help you buddy'
    })
})

// app.get('', (req, res)=>{
//      res.send('<h1>Hello Express</h1>')
// })
// app.get('/help', (req, res)=>{
//     res.send([
//         {
//           name : 'Nachiket',
//           age : 24
//         },
//         {
//             name : 'Avinash',
//             age : 30
//         }
// ])
// })
// app.get('/about', (req, res)=>{
//     res.send('<h1>About Page</h1>')
// })
app.get('/weather', (req, res)=>{
    if(!req.query.search){
        return res.send('Please provide the search query')
    }

    geocode(req.query.search, (error, {latitude, longitude} = {}) => {
        if(error){
          return res.send({error});
        }
        
         geolocation(latitude,longitude, (error, {cuurenttemp,feelslike,percip}) => {
          if(error){
            return res.send({error});
          }
          res.send({
            location : req.query.search,
            forecast : 'The current temperature is: '+cuurenttemp+' But its feelslike: '+feelslike+' and the chance of rain is '+percip+'%'
          })
        //   res.send('Weather data for '+data.location+','+data.state);
        //   console.log('The current temperature is: '+cuurenttemp+' But its feelslike: '+feelslike);
       })
      })

    // res.send({
    //     forecast : 'It is raining' ,
    //     location : req.query.search
    // })
})

app.get('/product', (req, res)=>{
    if(!req.query.search){
       return res.send('Please provide the search query')
    }
    res.send({
        products : []
    })
})

app.get('/help/*', (req,res)=>{
    res.render('NotFound', {
        helpnotfound : 'Help text not found',
        name :'Nachiket Singh'
    })
})

app.get('*', (req,res)=>{
    res.render('NotFound', {
        notfound : 'Page not Found',
        name : 'Nachiket Singh'
    })
})
app.listen(3000, ()=>{
    console.log('Server is up on port 3000')
})