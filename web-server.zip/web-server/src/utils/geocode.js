const request = require('request')
const geocode = (pika, callback) => {
    const url = 'http://api.positionstack.com/v1/forward?access_key=ce9dc716b99b5e0e3fb2f95029f2bc57&query=' +encodeURIComponent(pika);
     request({url: url, json : true}, (error, {body}) => {
      if(error){
            callback('Unable to connect with the service:', undefined);
          }else if(body.error){
            callback('Unable to find the location:', undefined)
          }else{
            callback(undefined,{
              latitude : body.data[0].latitude,
              longitude : body.data[0].longitude,
              location : body.data[0].name,
              state : body.data[0].region
            })
          }
     })
  }
  module.exports = geocode;