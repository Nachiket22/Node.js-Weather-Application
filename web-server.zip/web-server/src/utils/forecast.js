const request = require('request');
const geolocation = (tika, zika, callback) => {
    const urlr = 'http://api.weatherstack.com/current?access_key=33a9037315f59f13a97f7b19a6d83994&query='+(tika)+','+(zika);
  
     request({url : urlr, json : true}, (error, {body}) => {
      if(error){
            callback('Unable to connect with the service:', undefined);
          }else if(body.error){
            callback('Unable to find the location:', undefined)
          }else{
            callback(undefined,{
              cuurenttemp : body.current.temperature,
              feelslike : body.current.feelslike,
              percip : body.current.precip
            })
          }
     })
  }
  module.exports = geolocation;